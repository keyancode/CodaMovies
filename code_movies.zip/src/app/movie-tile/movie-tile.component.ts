import { Component, OnInit,Input,Output,EventEmitter } from '@angular/core';

@Component({
  selector: 'app-movie-tile',
  templateUrl: './movie-tile.component.html',
  styleUrls: ['./movie-tile.component.css']
})
export class MovieTileComponent implements OnInit {
  @Input() movieTitle : string;
  @Input() overview: string;
  @Input() adult: boolean;
  @Input() movieImgsrc : string;
  @Output() childResult : EventEmitter<string> = new EventEmitter <string>();
  dispAdult: string = "none";
  constructor() { }

  ngOnInit() {
    if(this.adult){
      this.dispAdult = "initial";
    }
  }

  buttonfunc(){
    /*if(this.src === 'pVal'){
      this.childResult.emit('HEY PARTNER PARENT');
    }else{
      this.childResult.emit('HEY SOCIAL PARENT');
    }*/
    
  }}
