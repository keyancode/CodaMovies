export interface Hospital {
    id: number, 
    name: string,
    location: string,
    contactPerson: string, 
    phone: number
}
