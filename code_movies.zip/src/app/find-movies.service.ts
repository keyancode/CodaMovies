import { Injectable } from '@angular/core';
import { HttpClient } from '../../node_modules/@angular/common/http';
import {MovieDetails} from 'src/app/movie-details';
import { Observable } from '../../node_modules/rxjs';


@Injectable({
  providedIn: 'root'
})
export class FindMoviesService {
  url: string = "https://api.themoviedb.org/3/search/movie?api_key=143b39b0265f0ad90c1c6febd580959e&query=";
  constructor(private http:HttpClient) { }

  findMovies(param :string): Observable<any>{
    return this.http.get(this.url+param);
  }
}
