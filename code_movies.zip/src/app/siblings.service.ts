import { Injectable } from '@angular/core';
import { BehaviorSubject, Observable } from '../../node_modules/rxjs';
import {MovieDetails} from 'src/app/movie-details';

@Injectable({
  providedIn: 'root'
})
export class SiblingsService {
  private messageSource:BehaviorSubject<MovieDetails []> = new
    BehaviorSubject<MovieDetails []>([]);

  constructor() { }

  changeMessage(message: MovieDetails[]) {

    this.messageSource.next(message);
    
    }
}
