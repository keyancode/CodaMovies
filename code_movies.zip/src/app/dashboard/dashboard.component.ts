import { Component, OnInit } from '@angular/core';
import {MovieDetails} from '../movie-details'; 
import { LoadTrendingMoviesService } from '../load-trending-movies.service';

@Component({
  selector: 'app-dashboard',
  templateUrl: './dashboard.component.html',
  styleUrls: ['./dashboard.component.css']
})
export class DashboardComponent implements OnInit {

  intent_tile: string = "Trending Movies"

  moviesDisplayed: MovieDetails[] = [];

    
  constructor(private service:LoadTrendingMoviesService) { }

  ngOnInit() {
    this.service.findTrendingMovies2().subscribe(resp => {this.moviesDisplayed =resp.results;
      this.moviesDisplayed.forEach(function(movie) {
        movie.poster_path = "http://image.tmdb.org/t/p/w185" + movie.poster_path ;
      });
    }
    );





console.log(this.moviesDisplayed);

  }

}
