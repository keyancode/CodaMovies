export interface MovieDetails {
    title: string ;
    poster_path: string;
    overview: string;
    adult: boolean;
}
