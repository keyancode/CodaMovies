import { TestBed, inject } from '@angular/core/testing';

import { FindMoviesService } from './find-movies.service';

describe('FindMoviesService', () => {
  beforeEach(() => {
    TestBed.configureTestingModule({
      providers: [FindMoviesService]
    });
  });

  it('should be created', inject([FindMoviesService], (service: FindMoviesService) => {
    expect(service).toBeTruthy();
  }));
});
