import { Injectable } from '@angular/core';
import { HttpClient } from '../../node_modules/@angular/common/http';
import {MovieDetails} from 'src/app/movie-details';
import { Observable } from '../../node_modules/rxjs';

@Injectable({
  providedIn: 'root'
})
export class LoadTrendingMoviesService {
 url: string = 'https://api.themoviedb.org/3/trending/movie/day?api_key=143b39b0265f0ad90c1c6febd580959e';
  constructor(private http:HttpClient) { }

  public findTrendingMovies(): Observable<MovieDetails[]>{
    return this.http.get<MovieDetails[]>(this.url);
  }

  findTrendingMovies2(): Observable<any>{
    return this.http.get(this.url);
  }
}
