import { TestBed, inject } from '@angular/core/testing';

import { LoadTrendingMoviesService } from './load-trending-movies.service';

describe('LoadTrendingMoviesService', () => {
  beforeEach(() => {
    TestBed.configureTestingModule({
      providers: [LoadTrendingMoviesService]
    });
  });

  it('should be created', inject([LoadTrendingMoviesService], (service: LoadTrendingMoviesService) => {
    expect(service).toBeTruthy();
  }));
});
