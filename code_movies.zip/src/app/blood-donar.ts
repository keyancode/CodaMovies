export interface BloodDonar {
    id: number, 
    name: string,
    mobileNumber: number,
    age: number, 
    bgroup: string, 
    location: string
}
