import { Component, OnInit} from '@angular/core';
import { SiblingsService } from '../siblings.service';
import {IImage} from '../iimage';
import {FindMoviesService} from '../find-movies.service';
import {MovieDetails} from '../movie-details'; 

//import { runInThisContext } from 'vm';

@Component({
  selector: 'app-header',
  templateUrl: './header.component.html',
  styleUrls: ['./header.component.css']
})
export class HeaderComponent implements OnInit {
  nameModel : string; 
  imageLoc : string;
  moviesDisplayed: MovieDetails[] = [];

  imageUrls: (string | IImage)[] = [
    { url: 'assets/MoviesBanners/seats.jpg', caption: 'Book your Favourite Seats!!', href: '#config' },
    { url: 'assets/MoviesBanners/popCorn.jpg', caption: 'Grab your PopCorn Free!!', clickAction: () => alert('custom click function') },
    { url: 'assets/MoviesBanners/mobApps.jpg', caption: 'Available on Play Store and App Store!!', backgroundSize: 'contain', backgroundPosition: 'center' }
  ];
  height: string = '400px';
  minHeight: string;
  arrowSize: string = '30px';
  showArrows: boolean = true;
  disableSwiping: boolean = false;
  autoPlay: boolean = true;
  autoPlayInterval: number = 3333;
  stopAutoPlayOnSlide: boolean = true;
  debug: boolean = false;
  backgroundSize: string = 'cover';
  backgroundPosition: string = 'center center';
  backgroundRepeat: string = 'no-repeat';
  showDots: boolean = true;
  dotColor: string = '#FFF';
  showCaptions: boolean = true;
  captionColor: string = '#FFF';
  captionBackground: string = 'rgba(0, 0, 0, .35)';
  lazyLoad: boolean = false;
  width: string = '100%';


   
  constructor(private service:SiblingsService,private service2: FindMoviesService) {
    this.nameModel = '';
    this.imageLoc = 'assets/bloodBank.gif';
    
   }

   ngOnInit() {

    
  }

  valName():boolean{
    if(this.nameModel.length>0){
      return true;
    }
    else{
      return false;
    }

  }

  
  findMovies(){
    this.service2.findMovies(this.nameModel).subscribe(resp => {this.moviesDisplayed =resp.results;
      this.moviesDisplayed.forEach(function(movie) {
        movie.poster_path = "http://image.tmdb.org/t/p/w185" + movie.poster_path ;
      });
    }
    );
    this.service.changeMessage(this.moviesDisplayed);
  }

}
